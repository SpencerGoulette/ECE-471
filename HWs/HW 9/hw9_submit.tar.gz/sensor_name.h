#define SENSOR_NAME "/sys/bus/w1/devices/28-000008d45b73/w1_slave"

