double read_temp(char *filename);
